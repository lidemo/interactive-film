// TODO: This can be a json file or a simple database

export default {
    "Introduction": {
        videoSrc: "files/intro.mov",
        choices: [
            {
                text: "Camden Town Greek Christening",
                nextNode: "camdenTown"
            },
            {
                text: "Chalk Farm Allotments",
                nextNode: "chalkFarm"
            }
        ]
    },
    "camdenTown": {
        videoSrc: "files/camdenTown.mov",
        choices: [
            {
                text: "Next Stop: Swiss Cottage",
                nextNode: "swissCottage"
            },
            {
                text: "Next Stop: Kilburn High Road",
                nextNode: "kilburnHighRoad"
            }
        ]
    },
    "chalkFarm": {
        videoSrc: "files/chalkFarm.mov",
        choices: [
            {
                text: "St Mary of the Angels at Bayswater",
                nextNode: "baysWaterChurch"
            },
            {
                text: "Notting Hill Gate",
                nextNode: "nottingHillGate"
            }
        ]
    },
    "swissCottage": {
        videoSrc: "files/swissCottage.mov",
        choices: [
            {
                text: "The World's End at Chelsea",
                nextNode: "worldsEnd"
            }
        ]
    },
    "kilburnHighRoad": {
        // Ending node with no choices
        videoSrc: "files/kilburnHighRoad.mov",
        choices: [
            {
                text: "The World's End at Chelsea",
                nextNode: "worldsEnd"
            }
        ]
	},
    "baysWaterChurch": {
        videoSrc: "files/bayswaterChurch.mov",
        choices: [
            {
                text: "The World's End at Chelsea",
                nextNode: "worldsEnd"
            }
        ]
    },
    "nottingHillGate": {
        // Ending node with no choices
        videoSrc: "files/nottingHillGate.mov",
        choices: [
            {
                text: "The World's End at Chelsea",
                nextNode: "worldsEnd"
            }
        ]
    },
    "worldsEnd": {
        videoSrc: "files/worldsEnd.mov",
        ending: "We made it to the World's End."
    }
};
